====================================================
 Hobgoblin                               Hunter,  02/16/2000 
 Quake2/baseq2/players/Hobgoblin         New York City/USA.                 
====================================================
 
	Authors

 Model/mesh - 	"Hunter"	Email: Hunter@Polycount.com
 Mapping    -	"Burnt Kona"	Email: burntkona@burnitbaby.co.uk
 Animations - 	"Fafner"  	Email: Fafner_@hotmail.com
 Skin       -   "Deranged"      Email: deranged@deathsdoor.com
 
        
====================================================

MODEL DESCRIPTION:

	A humanoid creature with big teeth, spiked shoulderpads, an earing and a big gun.  Will also be featured in Redchurch's "Awakening II" mod for Quake 2.     

CONSTRUCTION:
Poly Count              : 888 polys
Vert Count              : 392 Verts
Skin Count              : 1 Skin, for now, with more due from Burnt, Massive, Ogro etc.
Base Model              : New model
Editors used            : Believe it or not the entire model mesh was created with 			          Q2Modeler. Anims - Character studio.
Known Bugs              : A few little clipping problems
Build/Animation time    : Mesh - about a week, anims - about a month

Lows:
 I think I probably could have worked on the shape of the head or limbs more.. They look a little too "square" on some parts. Maybe I'll do a "freshened" up version one day for Q3A..

INSTALLATION:
Unzip the files into quake2/baseq2/players/hobgoblin

Don�t hesitate to send me a comment, feedback is the only way to learn anything.


	***Special thanks to Rogue13 (my Polycount Boss) Burnt Kona, Fafner, Deranged, shine, Massive Bitch, Soul Reaper, Magarnagal, Ogro_Fix, Evil Bastard, Gwot, Alphawolf, Malekyth, Stecki, sTuPiD fOoL, and about 291 other model authors who, in the past, have helped me out with advice, inspiration or tips, or never "blew me off" when I dropped them a question or two.. Its you gents that make Polycount, and the whole "modeling community" a friendly atmosphere and a vast well of information for the learners.


QUAKE(R) and QUAKE II(R) are registered trademarks of id Software, Inc.
You can't use this model for anything other than gaming, Without asking me first.

